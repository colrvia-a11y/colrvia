import { Palette, Story } from '@/lib/types';

function Swatch({ name, code, hex }: { name: string; code: string; hex?: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className="h-8 w-8 rounded-md border" style={{ background: hex || '#eee' }} />
      <div className="text-sm">
        <div className="font-medium">{name}</div>
        <div className="text-xs text-neutral-500">{code}</div>
      </div>
    </div>
  );
}

export function StoryCard({ story }: { story: Story }) {
  const pal = story.palette as Palette | undefined;
  return (
    <div className="card p-4">
      <div className="flex items-center justify-between">
        <div className="font-semibold">Palette #{story.id.slice(0, 6)}</div>
        <div className="text-xs text-neutral-500">{new Date(story.created_at).toLocaleString()}</div>
      </div>
      {pal && (
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
          {pal.swatches?.map((s, i) => (
            <Swatch key={i} name={s.name} code={s.code} hex={s.hex} />
          ))}
        </div>
      )}
      {story.notes && <p className="mt-4 text-sm text-neutral-700">{story.notes}</p>}
    </div>
  );
}
