import React from 'react';

export function GradientHeader({ title, subtitle, children }: { title?: string; subtitle?: string; children?: React.ReactNode }) {
  return (
    <div className="peach-hero">
      <div className="container-px pt-10 pb-16">
        {title && <h1 className="text-3xl sm:text-4xl font-semibold text-brand-green">{title}</h1>}
        {subtitle && <p className="mt-2 max-w-2xl text-brand-ink/80">{subtitle}</p>}
        {children && <div className="mt-6">{children}</div>}
      </div>
    </div>
  );
}
