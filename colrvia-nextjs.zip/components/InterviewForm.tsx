'use client';

import { useEffect, useMemo, useState } from 'react';
import schema from '@/schemas/single-room-color-intake.json';
import { ChoiceChipGroup } from './ChoiceChipGroup';
import { useRouter } from 'next/navigation';

type Question = {
  id: string;
  title: string;
  description?: string;
  type: 'string' | 'array' | 'boolean';
  enum?: string[];
  ui?: 'singleSelect' | 'multiSelect' | 'text' | 'longText' | 'boolean';
  showIf?: Record<string, any[]>;
  minLength?: number;
};

type Answers = Record<string, any>;

export default function InterviewForm() {
  const [answers, setAnswers] = useState<Answers>({});
  const router = useRouter();

  const questions: Question[] = useMemo(() => {
    const props = (schema as any).properties || {};
    const order = Object.keys(props);
    return order.map((key) => {
      const def = props[key];
      return {
        id: key,
        title: def.title || key,
        description: def.description,
        type: def.type,
        enum: def.enum,
        ui: def.ui as any,
        showIf: def.showIf,
        minLength: def.minLength,
      } as Question;
    });
  }, []);

  const shouldShow = (q: Question) => {
    if (!q.showIf) return true;
    return Object.entries(q.showIf).every(([dep, allowed]) => {
      const v = answers[dep];
      if (Array.isArray(v)) return v.some((x) => allowed.includes(x));
      return allowed.includes(v);
    });
  };

  const visible = questions.filter(shouldShow);

  const submit = async () => {
    const res = await fetch('/api/story', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ answers }),
    });
    const data = await res.json();
    const redirectTo = '/reveal?id=' + encodeURIComponent(data.id);
    router.push(`/auth/callback?redirectTo=${encodeURIComponent(redirectTo)}`);
  };

  return (
    <form className="space-y-6">
      {visible.map((q) => (
        <div key={q.id}>
          <label className="block text-sm font-medium">{q.title}</label>
          {q.description && <p className="text-xs text-neutral-500 mt-1">{q.description}</p>}

          {q.ui === 'singleSelect' && q.enum && (
            <ChoiceChipGroup
              options={q.enum.map((id) => ({ id, label: id }))}
              value={answers[q.id] ?? null}
              onChange={(v) => setAnswers((a) => ({ ...a, [q.id]: v }))}
            />
          )}

          {q.ui === 'multiSelect' && q.enum && (
            <ChoiceChipGroup
              options={q.enum.map((id) => ({ id, label: id }))}
              value={(answers[q.id] as string[]) ?? []}
              onChange={(v) => setAnswers((a) => ({ ...a, [q.id]: v }))}
              multi
            />
          )}

          {(!q.ui || q.ui === 'text' || q.ui === 'longText') && (
            <input
              className="mt-2 w-full rounded-2xl border px-3 py-2"
              placeholder="Type your answer"
              value={answers[q.id] ?? ''}
              onChange={(e) => setAnswers((a) => ({ ...a, [q.id]: e.target.value }))}
            />
          )}
        </div>
      ))}

      <button type="button" className="btn-primary" onClick={submit}>
        Create My Palette
      </button>
    </form>
  );
}
