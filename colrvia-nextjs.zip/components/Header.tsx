'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';

export function Header() {
  const [hiddenOnMobile, setHiddenOnMobile] = useState(true);
  useEffect(() => {
    // Always hide on widths < 640px
    const onResize = () => setHiddenOnMobile(window.innerWidth < 640);
    onResize();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  return (
    <header className={(hiddenOnMobile ? 'hidden sm:block ' : '') + 'container-px py-4'}>
      <div className="flex items-center justify-between">
        <Link href="/" className="font-semibold text-brand-green">Colrvia</Link>
        <nav className="flex items-center gap-4">
          <Link href="/start/interview-intro" className="hover:underline">Start</Link>
          <Link href="/via" className="hover:underline">Via Chat</Link>
          <Link href="/dashboard" className="hover:underline">Dashboard</Link>
        </nav>
      </div>
    </header>
  );
}
