'use client';

import { useEffect, useRef, useState } from 'react';

type Msg = {
  id: string;
  text: string;
  role: 'user' | 'assistant' | 'system';
  createdAt: number;
  images?: string[];
};

export default function ChatUI() {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [text, setText] = useState('');
  const [introVisible, setIntroVisible] = useState(true);
  const scrollerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollerRef.current?.scrollTo({ top: scrollerRef.current.scrollHeight });
  }, [messages.length]);

  const send = async () => {
    if (!text.trim()) return;
    const userMsg: Msg = { id: crypto.randomUUID(), text, role: 'user', createdAt: Date.now() };
    setMessages((m) => [...m, userMsg]);
    setIntroVisible(false);
    setText('');

    const res = await fetch('/api/via', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: [...messages, userMsg].slice(-12) }),
    });
    const data = await res.json();
    const bot: Msg = { id: crypto.randomUUID(), text: data.reply || 'Okay!', role: 'assistant', createdAt: Date.now() };
    setMessages((m) => [...m, bot]);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)]">
      <div className="peach-hero">
        <div className="container-px py-8">
          {introVisible && (
            <div>
              <h1 className="text-3xl font-semibold text-brand-green">Hi, I’m Via 👋</h1>
              <p className="text-brand-ink/80 mt-2">
                Ask me anything paint & palette. Share a photo, undertone questions, or tell me your vibe.
              </p>
            </div>
          )}
        </div>
      </div>

      <div ref={scrollerRef} className="container-px flex-1 overflow-y-auto py-6 space-y-4">
        {messages.map((m) => (
          <div key={m.id} className={m.role === 'user' ? 'text-right' : 'text-left'}>
            <div className={
              'inline-block rounded-2xl px-4 py-2 ' +
              (m.role === 'user' ? 'bg-brand-green text-white' : 'bg-neutral-100 text-brand-ink')
            }>{m.text}</div>
          </div>
        ))}
      </div>

      <div className="border-t bg-white">
        <div className="container-px py-3">
          <div className="flex gap-2">
            <input
              className="flex-1 rounded-2xl border px-3 py-2 bg-white text-brand-ink placeholder-neutral-400"
              placeholder="Type your message..."
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && send()}
            />
            <button className="btn-primary" onClick={send}>Send</button>
          </div>
          <p className="text-xs text-neutral-500 mt-2">Black text on white input for readability.</p>
        </div>
      </div>
    </div>
  );
}
