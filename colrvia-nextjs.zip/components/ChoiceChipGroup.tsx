'use client';

import clsx from 'clsx';

export function ChoiceChipGroup({
  options,
  value,
  onChange,
  multi = false,
}: {
  options: { id: string; label: string }[];
  value: string | string[] | null;
  onChange: (val: string | string[] | null) => void;
  multi?: boolean;
}) {
  const setNext = (id: string) => {
    if (!multi) {
      onChange(value === id ? null : id);
    } else {
      const arr = Array.isArray(value) ? [...value] : [];
      const i = arr.indexOf(id);
      if (i >= 0) arr.splice(i, 1);
      else arr.push(id);
      onChange(arr);
    }
  };
  const isActive = (id: string) => (Array.isArray(value) ? value.includes(id) : value === id);

  return (
    <div className="flex flex-wrap gap-2">
      {options.map((opt) => (
        <button
          key={opt.id}
          type="button"
          onClick={() => setNext(opt.id)}
          className={clsx(
            'px-3 py-1.5 rounded-2xl border text-sm',
            isActive(opt.id)
              ? 'bg-brand-green text-white border-brand-green'
              : 'bg-white text-brand-ink border-neutral-300 hover:bg-neutral-100'
          )}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}
