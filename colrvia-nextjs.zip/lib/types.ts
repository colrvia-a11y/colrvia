export type InterviewAnswer = Record<string, any>;

export type Story = {
  id: string;
  created_at: string;
  notes?: string;
  palette?: Palette;
};

export type Palette = {
  brand: string;
  swatches: {
    code: string;
    name: string;
    hex?: string;
    role?: 'walls' | 'trim' | 'accent' | 'cabinetry' | 'ceiling' | 'door';
  }[];
};
