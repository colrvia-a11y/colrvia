import { NextResponse } from 'next/server';
import type { Palette, Story } from '@/lib/types';

function generateMockPalette(): Palette {
  const swatches = [
    { brand: 'Sherwin-Williams', code: 'SW 7008', name: 'Alabaster', hex: '#EDEAE0', role: 'trim' },
    { brand: 'Sherwin-Williams', code: 'SW 7674', name: 'Peppercorn', hex: '#4B4F54', role: 'walls' },
    { brand: 'Sherwin-Williams', code: 'SW 6258', name: 'Tricorn Black', hex: '#2B2B2B', role: 'accent' },
    { brand: 'Sherwin-Williams', code: 'SW 6171', name: 'Chatroom', hex: '#A9A693', role: 'cabinetry' },
  ];
  return { brand: 'Sherwin-Williams', swatches };
}

// simple in-memory store for demo
const store = new Map<string, Story>();

export async function POST(req: Request) {
  const { answers } = await req.json();
  const id = crypto.randomUUID();
  const story: Story = {
    id,
    created_at: new Date().toISOString(),
    notes: 'Mock notes: smooth contrast, undertone-safe with veining. Adjust depth by light.',
    palette: generateMockPalette(),
  };
  store.set(id, story);

  return NextResponse.json({ id });
}

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = searchParams.get('id');
  if (!id || !store.has(id)) {
    return NextResponse.json({ error: 'not_found' }, { status: 404 });
  }
  return NextResponse.json({ story: store.get(id) });
}
