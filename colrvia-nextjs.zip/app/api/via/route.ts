import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  const body = await req.json();
  const messages = body.messages || [];

  // If OPENAI_API_KEY is present, call OpenAI; otherwise respond with a helpful mock.
  if (process.env.OPENAI_API_KEY) {
    try {
      const payload = {
        model: 'gpt-5-thinking',
        messages: [
          { role: 'system', content: 'You are Via, a friendly, expert residential color designer. Keep answers practical and brand-consistent.' },
          ...messages.map((m: any) => ({ role: m.role, content: m.text })),
        ],
      };
      const resp = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        },
        body: JSON.stringify(payload),
      });
      const data = await resp.json();
      const reply = data?.choices?.[0]?.message?.content ?? 'I have some ideas for your palette. Could you share a bit more?';
      return NextResponse.json({ reply });
    } catch (err) {
      return NextResponse.json({ reply: 'Having trouble reaching the AI. Using a backup for now.' });
    }
  }

  // Mock response
  const last = messages.at(-1)?.text || '';
  const reply = last
    ? `Got it. Based on: “${last}”, consider Sherwin-Williams Peppercorn (walls), Alabaster (trim), and Tricorn Black (accent).`
    : 'Tell me about your space, lighting, and any colors to avoid.';
  return NextResponse.json({ reply });
}
