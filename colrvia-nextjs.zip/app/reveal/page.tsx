'use client';
import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { StoryCard } from '@/components/StoryCard';
import type { Story } from '@/lib/types';

export default function RevealPage() {
  const [story, setStory] = useState<Story | null>(null);
  const params = useSearchParams();
  const id = params.get('id');

  useEffect(() => {
    if (!id) return;
    (async () => {
      const res = await fetch('/api/story?id=' + encodeURIComponent(id));
      const data = await res.json();
      setStory(data.story);
    })();
  }, [id]);

  if (!id) return <div className="container-px py-8">Missing story id.</div>;
  if (!story) return <div className="container-px py-8">Loading…</div>;

  return (
    <div className="container-px py-8">
      <h1 className="text-2xl font-semibold mb-4">Your Palette</h1>
      <StoryCard story={story} />
    </div>
  );
}
