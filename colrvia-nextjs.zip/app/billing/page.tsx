export default function BillingPage() {
  return (
    <div className="container-px py-8">
      <h1 className="text-2xl font-semibold">Billing</h1>
      <p className="mt-2 text-neutral-600">Connect Stripe and set up plans. First palette free, then paywall.</p>
    </div>
  );
}
