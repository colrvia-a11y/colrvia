import InterviewForm from '@/components/InterviewForm';
import { GradientHeader } from '@/components/GradientHeader';

export default function TextInterviewPage() {
  return (
    <div>
      <GradientHeader
        title="Tell us about your room"
        subtitle="We’ll use this to pick colors that look great and are easy to live with."
      />
      <section className="container-px py-8">
        <div className="card p-6">
          <InterviewForm />
        </div>
      </section>
    </div>
  );
}
