import Link from 'next/link';
import { GradientHeader } from '@/components/GradientHeader';

export default function InterviewIntro() {
  return (
    <div>
      <GradientHeader
        title="Pick your interview style"
        subtitle="Both take ~3–5 minutes and produce the same personalized results."
      />
      <section className="container-px py-8 grid gap-4 sm:grid-cols-2">
        <div className="card p-5">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Talk with Via AI</h3>
            <span className="text-xs text-neutral-500">Hands-free</span>
          </div>
          <p className="mt-2 text-sm text-neutral-700">Answer verbally, let Via handle the typing. Great if you prefer to describe your space out loud.</p>
          <Link href="/via" className="btn-primary mt-4 inline-block">Start Talking</Link>
        </div>

        <div className="card p-5">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Chat / Text Form</h3>
            <span className="text-xs text-neutral-500">Faster</span>
          </div>
          <p className="mt-2 text-sm text-neutral-700">Simple questions with smart follow‑ups based on your answers.</p>
          <Link href="/interview/text" className="btn-light mt-4 inline-block">Start Text Interview</Link>
        </div>
      </section>
    </div>
  );
}
