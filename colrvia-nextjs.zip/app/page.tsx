import Link from 'next/link';
import { GradientHeader } from '@/components/GradientHeader';

export default function HomePage() {
  return (
    <div>
      <GradientHeader
        title="Color, Your Way™"
        subtitle="A calm, cohesive home paint palette in minutes. Via AI guides you, you approve."
      >
        <div className="flex flex-wrap gap-3">
          <Link href="/start/interview-intro" className="btn-primary">Start</Link>
          <Link href="/via" className="btn-light">Chat with Via</Link>
        </div>
      </GradientHeader>

      <section className="container-px py-10">
        <h2 className="text-xl font-semibold">How it works</h2>
        <ol className="mt-4 grid gap-4 sm:grid-cols-3">
          <li className="card p-4">1. Quick interview (text or talk).</li>
          <li className="card p-4">2. Via builds your palette using real brands.</li>
          <li className="card p-4">3. Review, tweak, and save. First one’s free.</li>
        </ol>
      </section>
    </div>
  );
}
