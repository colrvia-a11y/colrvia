export default function DashboardPage() {
  return (
    <div className="container-px py-8">
      <h1 className="text-2xl font-semibold">Dashboard</h1>
      <p className="mt-2 text-neutral-600">Saved palettes and projects will appear here.</p>
    </div>
  );
}
